#define UTS_RELEASE "2.6.32-21-generic-pae"
