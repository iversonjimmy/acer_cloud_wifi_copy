#ifndef __ASM_SH_LMB_H
#define __ASM_SH_LMB_H

#define LMB_REAL_LIMIT	0

#endif /* __ASM_SH_LMB_H */
