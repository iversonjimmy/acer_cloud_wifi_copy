#ifndef _CRIS_BYTEORDER_H
#define _CRIS_BYTEORDER_H

#include <linux/byteorder/little_endian.h>

#endif


