#ifndef _CRIS_RESOURCE_H
#define _CRIS_RESOURCE_H

#include <asm-generic/resource.h>

#endif
