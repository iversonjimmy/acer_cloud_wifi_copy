#ifndef _ASM_CACHE_H
#define _ASM_CACHE_H

#include <arch/cache.h>

#endif /* _ASM_CACHE_H */
