#ifndef _CRIS_SIGINFO_H
#define _CRIS_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif
