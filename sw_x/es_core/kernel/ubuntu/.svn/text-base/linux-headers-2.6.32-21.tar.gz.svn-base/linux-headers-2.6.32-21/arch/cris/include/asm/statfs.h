#ifndef _CRIS_STATFS_H
#define _CRIS_STATFS_H

#include <asm-generic/statfs.h>

#endif
