#ifndef __ASM_SH_ERRNO_H
#define __ASM_SH_ERRNO_H

#include <asm-generic/errno.h>

#endif /* __ASM_SH_ERRNO_H */
