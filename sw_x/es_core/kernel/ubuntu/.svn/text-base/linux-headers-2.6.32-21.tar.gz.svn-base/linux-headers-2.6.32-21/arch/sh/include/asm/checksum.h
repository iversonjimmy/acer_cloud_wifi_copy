#ifdef CONFIG_SUPERH32
# include "checksum_32.h"
#else
# include <asm-generic/checksum.h>
#endif
