#ifndef __ASM_SH_SCATTERLIST_H
#define __ASM_SH_SCATTERLIST_H

#define ISA_DMA_THRESHOLD	PHYS_ADDR_MASK

#include <asm-generic/scatterlist.h>

#endif /* __ASM_SH_SCATTERLIST_H */
