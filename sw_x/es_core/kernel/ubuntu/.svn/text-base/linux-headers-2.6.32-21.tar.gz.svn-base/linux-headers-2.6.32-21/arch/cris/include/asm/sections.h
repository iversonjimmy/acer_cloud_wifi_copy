#ifndef _CRIS_SECTIONS_H
#define _CRIS_SECTIONS_H

/* nothing to see, move along */
#include <asm-generic/sections.h>

#endif
