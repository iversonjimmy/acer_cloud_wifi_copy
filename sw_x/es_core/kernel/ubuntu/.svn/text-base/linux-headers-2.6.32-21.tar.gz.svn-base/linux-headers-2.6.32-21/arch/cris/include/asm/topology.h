#ifndef _ASM_CRIS_TOPOLOGY_H
#define _ASM_CRIS_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* _ASM_CRIS_TOPOLOGY_H */
