#ifndef __SH_CPUTIME_H
#define __SH_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __SH_CPUTIME_H */
