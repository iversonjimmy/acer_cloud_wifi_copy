#ifndef __ARCH_SH_PERCPU
#define __ARCH_SH_PERCPU

#include <asm-generic/percpu.h>

#endif /* __ARCH_SH_PERCPU */
