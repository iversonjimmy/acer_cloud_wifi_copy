#ifdef CONFIG_SUPERH32
# include "string_32.h"
#else
# include "string_64.h"
#endif
