#ifndef _CRIS_ERRNO_H
#define _CRIS_ERRNO_H

#include <asm-generic/errno.h>

#endif
