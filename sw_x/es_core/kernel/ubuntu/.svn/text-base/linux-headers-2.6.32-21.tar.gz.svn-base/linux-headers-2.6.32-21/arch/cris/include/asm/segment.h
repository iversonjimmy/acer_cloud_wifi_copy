#ifndef _ASM_SEGMENT_H
#define _ASM_SEGMENT_H

typedef struct {
  unsigned long seg;
} mm_segment_t;

#endif
