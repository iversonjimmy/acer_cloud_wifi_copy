/* $Id: bugs.h,v 1.2 2001/01/17 17:03:18 bjornw Exp $
 *
 *  include/asm-cris/bugs.h
 *
 *  Copyright (C) 2001 Axis Communications AB
 */

/*
 * This is included by init/main.c to check for architecture-dependent bugs.
 *
 * Needs:
 *	void check_bugs(void);
 */

static void check_bugs(void)
{
}




