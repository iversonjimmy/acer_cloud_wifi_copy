#ifndef __ASM_SH_SIGINFO_H
#define __ASM_SH_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif /* __ASM_SH_SIGINFO_H */
