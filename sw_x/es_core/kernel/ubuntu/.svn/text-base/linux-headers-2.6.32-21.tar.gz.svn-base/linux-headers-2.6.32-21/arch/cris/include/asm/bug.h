#ifndef _CRIS_BUG_H
#define _CRIS_BUG_H
#include <arch/bug.h>
#endif
